module LCD5110 (
    input  wire clk,
    output reg lcd_rst = 0,
    output reg lcd_ce  = 1,
    output reg lcd_dc  = 0,
    output reg lcd_din = 0,
    output reg lcd_clk = 0
);

    // Nokia 5110 - PCD8544
    // FPGA clock: 50 MHz

    function [7:0] init_byte;
        input [2:0] n;
        begin
            case (n)
                0: init_byte = 8'h21;
                1: init_byte = 8'hB8;
                2: init_byte = 8'h04;
                3: init_byte = 8'h14;
                4: init_byte = 8'h20;
                5: init_byte = 8'h0C;
                6: init_byte = 8'h80;
                7: init_byte = 8'h40;
                default: init_byte = 8'h00;
            endcase
        end
    endfunction

    // Font 5x7:
    // Row 2 (0..83):   Nico-Mihai-   (padded to 84 px to wrap cleanly)
    // Row 3 (84..155): Andrei-Maria
    function [7:0] text_byte;
        input [7:0] n;
        begin
            case (n)
                // --- LINE 1: Nico-Mihai- ---

                // N
                  0: text_byte = 8'h7F;
                  1: text_byte = 8'h02;
                  2: text_byte = 8'h0C;
                  3: text_byte = 8'h10;
                  4: text_byte = 8'h7F;

                // i
                  6: text_byte = 8'h00;
                  7: text_byte = 8'h44;
                  8: text_byte = 8'h7D;
                  9: text_byte = 8'h40;
                 10: text_byte = 8'h00;

                // c
                 12: text_byte = 8'h38;
                 13: text_byte = 8'h44;
                 14: text_byte = 8'h44;
                 15: text_byte = 8'h44;
                 16: text_byte = 8'h20;

                // o
                 18: text_byte = 8'h38;
                 19: text_byte = 8'h44;
                 20: text_byte = 8'h44;
                 21: text_byte = 8'h44;
                 22: text_byte = 8'h38;

                // -
                 24: text_byte = 8'h08;
                 25: text_byte = 8'h08;
                 26: text_byte = 8'h08;
                 27: text_byte = 8'h08;
                 28: text_byte = 8'h08;

                // M
                 30: text_byte = 8'h7F;
                 31: text_byte = 8'h02;
                 32: text_byte = 8'h0C;
                 33: text_byte = 8'h02;
                 34: text_byte = 8'h7F;

                // i
                 36: text_byte = 8'h00;
                 37: text_byte = 8'h44;
                 38: text_byte = 8'h7D;
                 39: text_byte = 8'h40;
                 40: text_byte = 8'h00;

                // h
                 42: text_byte = 8'h7F;
                 43: text_byte = 8'h08;
                 44: text_byte = 8'h04;
                 45: text_byte = 8'h04;
                 46: text_byte = 8'h78;

                // a
                 48: text_byte = 8'h20;
                 49: text_byte = 8'h54;
                 50: text_byte = 8'h54;
                 51: text_byte = 8'h54;
                 52: text_byte = 8'h78;

                // i
                 54: text_byte = 8'h00;
                 55: text_byte = 8'h44;
                 56: text_byte = 8'h7D;
                 57: text_byte = 8'h40;
                 58: text_byte = 8'h00;

                // -
                 60: text_byte = 8'h08;
                 61: text_byte = 8'h08;
                 62: text_byte = 8'h08;
                 63: text_byte = 8'h08;
                 64: text_byte = 8'h08;

                // (65..83 default to 8'h00 to pad to 84 pixels)

                // --- LINE 2: Andrei-Maria ---

                // A
                 84: text_byte = 8'h7E;
                 85: text_byte = 8'h11;
                 86: text_byte = 8'h11;
                 87: text_byte = 8'h11;
                 88: text_byte = 8'h7E;

                // n
                 90: text_byte = 8'h7C;
                 91: text_byte = 8'h08;
                 92: text_byte = 8'h04;
                 93: text_byte = 8'h04;
                 94: text_byte = 8'h78;

                // d
                 96: text_byte = 8'h38;
                 97: text_byte = 8'h44;
                 98: text_byte = 8'h44;
                 99: text_byte = 8'h48;
                100: text_byte = 8'h7F;

                // r
                102: text_byte = 8'h7C;
                103: text_byte = 8'h08;
                104: text_byte = 8'h04;
                105: text_byte = 8'h04;
                106: text_byte = 8'h08;

                // e
                108: text_byte = 8'h38;
                109: text_byte = 8'h54;
                110: text_byte = 8'h54;
                111: text_byte = 8'h54;
                112: text_byte = 8'h18;

                // i
                114: text_byte = 8'h00;
                115: text_byte = 8'h44;
                116: text_byte = 8'h7D;
                117: text_byte = 8'h40;
                118: text_byte = 8'h00;

                // -
                120: text_byte = 8'h08;
                121: text_byte = 8'h08;
                122: text_byte = 8'h08;
                123: text_byte = 8'h08;
                124: text_byte = 8'h08;

                // M
                126: text_byte = 8'h7F;
                127: text_byte = 8'h02;
                128: text_byte = 8'h0C;
                129: text_byte = 8'h02;
                130: text_byte = 8'h7F;

                // a
                132: text_byte = 8'h20;
                133: text_byte = 8'h54;
                134: text_byte = 8'h54;
                135: text_byte = 8'h54;
                136: text_byte = 8'h78;

                // r
                138: text_byte = 8'h7C;
                139: text_byte = 8'h08;
                140: text_byte = 8'h04;
                141: text_byte = 8'h04;
                142: text_byte = 8'h08;

                // i
                144: text_byte = 8'h00;
                145: text_byte = 8'h44;
                146: text_byte = 8'h7D;
                147: text_byte = 8'h40;
                148: text_byte = 8'h00;

                // a
                150: text_byte = 8'h20;
                151: text_byte = 8'h54;
                152: text_byte = 8'h54;
                153: text_byte = 8'h54;
                154: text_byte = 8'h78;

                // Spatii intre litere si padding linie
                default: text_byte = 8'h00;

            endcase
        end
    endfunction

    // 0 = initializare
    // 1 = stergere ecran
    // 2 = pozitionare cursor
    // 3 = Nico-Mihai-Andrei-Maria

    reg [1:0] phase = 0;
    reg [9:0] pos = 0;

    wire [7:0] tx_byte =
        (phase == 0) ? init_byte(pos[2:0]) :
        (phase == 1) ? 8'h00 :
        (phase == 2) ?
            ((pos == 0) ? 8'h80 : 8'h42) :
        text_byte(pos[7:0]);

    localparam RESET_LOW  = 0;
    localparam RESET_HIGH = 1;
    localparam LOAD       = 2;
    localparam CLOCK_UP   = 3;
    localparam CLOCK_DOWN = 4;
    localparam BYTE_END   = 5;
    localparam ADVANCE    = 6;
    localparam DONE       = 7;

    reg [3:0] state = RESET_LOW;
    reg [21:0] timer = 0;
    reg [5:0] spi_div = 0;
    reg [7:0] shift_byte = 0;
    reg [2:0] bit_index = 0;

    always @(posedge clk) begin
        case (state)

            RESET_LOW: begin
                lcd_rst <= 0;
                lcd_ce <= 1;
                lcd_clk <= 0;

                if (timer == 22'd999999) begin
                    timer <= 0;
                    lcd_rst <= 1;
                    state <= RESET_HIGH;
                end
                else
                    timer <= timer + 1'b1;
            end

            RESET_HIGH: begin
                if (timer == 22'd2499999) begin
                    timer <= 0;
                    state <= LOAD;
                end
                else
                    timer <= timer + 1'b1;
            end

            LOAD: begin
                lcd_ce <= 0;
                lcd_dc <= (phase == 1 ||
                           phase == 3);
                lcd_clk <= 0;
                lcd_din <= tx_byte[7];

                shift_byte <= tx_byte;
                bit_index <= 7;
                spi_div <= 0;
                state <= CLOCK_UP;
            end

            CLOCK_UP: begin
                if (spi_div == 49) begin
                    spi_div <= 0;
                    lcd_clk <= 1;
                    state <= CLOCK_DOWN;
                end
                else
                    spi_div <= spi_div + 1'b1;
            end

            CLOCK_DOWN: begin
                if (spi_div == 49) begin
                    spi_div <= 0;
                    lcd_clk <= 0;

                    if (bit_index == 0)
                        state <= BYTE_END;
                    else begin
                        bit_index <= bit_index - 1'b1;
                        lcd_din <= shift_byte[6];
                        shift_byte <=
                            {shift_byte[6:0], 1'b0};
                        state <= CLOCK_UP;
                    end
                end
                else
                    spi_div <= spi_div + 1'b1;
            end

            BYTE_END: begin
                lcd_ce <= 1;
                state <= ADVANCE;
            end

            ADVANCE: begin

                if (phase == 3 && pos == 155)
                    state <= DONE;

                else begin
                    state <= LOAD;

                    if (phase == 0 && pos == 7) begin
                        phase <= 1;
                        pos <= 0;
                    end

                    else if (phase == 1 &&
                             pos == 503) begin
                        phase <= 2;
                        pos <= 0;
                    end

                    else if (phase == 2 &&
                             pos == 1) begin
                        phase <= 3;
                        pos <= 0;
                    end

                    else
                        pos <= pos + 1'b1;
                end
            end

            DONE: begin
                lcd_ce <= 1;
                lcd_clk <= 0;
            end

            default:
                state <= RESET_LOW;

        endcase
    end

endmodule